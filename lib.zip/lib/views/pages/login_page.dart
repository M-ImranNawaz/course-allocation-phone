import 'dart:async';

import 'package:course_allocation_phone/controllers/login_controller.dart';
import 'package:course_allocation_phone/contstants.dart';
import 'package:course_allocation_phone/views/widgets/passwordfield_widget.dart';
import 'package:flutter/material.dart';
import '../widgets/button_widget.dart';
import '../widgets/textformfield_widget.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({Key? key}) : super(key: key);

  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  late LoginController controller;
  @override
  void initState() {
    super.initState();
    controller = LoginController();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      backgroundColor: Colors.blue[100],
      body: SafeArea(
        child: Column(
          children: [
            SizedBox(
              height: MediaQuery.of(context).size.height / 3.3,
              child: Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    Image.asset('assets/icon.png', width: 100),
                    const Text(
                      'Welcome',
                      style: TextStyle(
                        fontSize: 50,
                        color: kKfueitGreen,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Form(
              key: controller.formKey,
              child: Expanded(
                child: Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
                  decoration: const BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(20),
                        topRight: Radius.circular(20)),
                  ),
                  alignment: Alignment.center,
                  child: Column(
                    children: [
                      const Text(
                        'SIGN IN',
                        style: TextStyle(
                            color: kKfueitblue,
                            fontSize: 40,
                            fontWeight: FontWeight.w500),
                      ),
                      TextFormFieldWidget(
                          controller: controller.nameC,
                          icon: Icons.person,
                          label: 'User Name',
                          validator: (value) {
                            if (value.length < 5) {
                              return 'User Name is Too Short';
                            }
                          }),
                      PasswordField(controller: controller),
                      Container(
                        child: controller.isLoading.value == false
                            ? ButtonWidget(
                                //_validation,
                                () {
                                  controller.validation();
                                },
                                'Login',
                              )
                            : const Center(child: CircularProgressIndicator()),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _showMyDialog() async {
    return showDialog<void>(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Failed to LoginPage'),
          content: const Text(
              'Please LoginPage with authenticated user name and password or with authenticated device'),
          actions: <Widget>[
            TextButton(
              child: const Text('Try Again'),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }
}
