import 'package:course_allocation_phone/controllers/ac_controller.dart';
import 'package:course_allocation_phone/views/pages/add_courses_page.dart';
import 'package:course_allocation_phone/views/pages/login_page.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../main.dart';
import '../../models/course.dart';

class AllocatedCourses extends StatefulWidget {
  const AllocatedCourses({Key? key}) : super(key: key);

  @override
  State<AllocatedCourses> createState() => _AllocatedCoursesState();
}

class _AllocatedCoursesState extends State<AllocatedCourses> {
  late ACController controller;
  @override
  void initState() {
    controller = ACController();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
            leading: InkWell(
              onTap: () {
                Navigator.pushReplacement(context,
                    MaterialPageRoute(builder: (_) => const LoginPage()));
                prefs.clear();
              },
              child: const Padding(
                padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                child: Icon(Icons.logout),
              ),
            ),
            title: const Text('Allocated Courses'),
            actions: [
              InkWell(
                  onTap: () {},
                  child: const Padding(
                    padding: EdgeInsets.symmetric(horizontal: 8.0, vertical: 4),
                    child: Icon(Icons.notifications),
                  )),
              Tooltip(
                message: 'Add Courses',
                child: InkWell(
                    onTap: () {
                      Get.to(() => const AddCourses());
                    },
                    child: const Padding(
                      padding:
                          EdgeInsets.symmetric(horizontal: 8.0, vertical: 4),
                      child: Icon(Icons.add),
                    )),
              ),
            ]),
        body: Center(
          child: FutureBuilder<List<Course>>(
            future: controller.getData(),
            builder: (context, snapshot) {
              if (snapshot.hasData) {
                final courses = snapshot.data!;
                return buildCourseView(courses);
              }
              if (snapshot.hasError) {
                return const Center(child: Text('ERROR'));
              }
              return const Center(
                child: CircularProgressIndicator(),
              );
            },
          ),
        ));
  }

  Center buildCourseView(List<Course> courses) {
    return Center(
      child: ListView.builder(
          shrinkWrap: true,
          itemCount: courses.length,
          itemBuilder: ((context, index) {
            var c = courses.elementAt(index);
            return Padding(
              padding: const EdgeInsets.all(8.0),
              child: Table(
                defaultVerticalAlignment: TableCellVerticalAlignment.middle,
                border: TableBorder.all(),
                columnWidths: const {
                  0: FixedColumnWidth(120.0),
                },
                children: [
                  TableRow(
                    children: [
                      buildTextField("Name"),
                      buildTextField(c.name),
                    ],
                  ),
                  TableRow(
                    children: [
                      buildTextField("Course Code"),
                      buildTextField(c.code),
                    ],
                  ),
                  TableRow(

                    children: [

                      buildTextField("Section"),
                      buildTextField("${c.program} "
                          "${c.department} "
                          "${c.semester.length == 1 ? '${c.semester}-A' : c.semester}"),
                    ],
                  ),
                ],
              ),
            );
          })),
    );
  }

  Widget buildTextField(data) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3, horizontal: 6),
      child: SelectableText(
        data,
        //textAlign: TextAlign.center,
      ),
    );
  }
}
