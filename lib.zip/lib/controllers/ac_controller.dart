import 'package:course_allocation_phone/contstants.dart';
import 'package:course_allocation_phone/main.dart';
import 'package:get/get.dart';
import '../models/course.dart';
import 'base_controller.dart';
import '../services/base_client.dart';

class ACController extends GetxController with BaseController {
  List<Course> courses = [];
  Future<List<Course>> getData() async {
    BaseClient baseClient = BaseClient();
    var response = await baseClient.post(kBaseUrl, 'getacbyid',
        {"id": facultyId.toString()}).catchError(handleError);
    print(response.toString());
    if (response == null) return [];
    courses = response['Courses'].map<Course>(Course.fromJson).toList();
    print('id is: $facultyId');
    return courses;
  }
}
